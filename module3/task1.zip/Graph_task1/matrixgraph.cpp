#include "MatrixGraph.h"

MatrixGraph::MatrixGraph(size_t vertex_count)
    : adjacency_matrix(vertex_count, std::vector<int>(vertex_count, 0)), vertex_count(vertex_count) {}

MatrixGraph::MatrixGraph(const IGraph &other_graph)
    : adjacency_matrix(other_graph.VerticesCount(), std::vector<int>(other_graph.VerticesCount(), 0)), vertex_count(other_graph.VerticesCount()) {
    for (size_t vertex = 0; vertex < vertex_count; ++vertex) {
        for (int next_vertex : other_graph.GetNextVertices(vertex)) {
            AddEdge(vertex, next_vertex);
        }
    }
}

MatrixGraph::~MatrixGraph() {}

void MatrixGraph::AddEdge(int from, int to) {
    assert(from >= 0 && from < vertex_count);
    assert(to >= 0 && to < vertex_count);
    adjacency_matrix[from][to] += 1;
}

int MatrixGraph::VerticesCount() const {
    return vertex_count;
}

std::vector<int> MatrixGraph::GetNextVertices(int vertex) const {
    assert(vertex >= 0 && vertex < vertex_count);
    std::vector<int> next_vertices;
    for (size_t i = 0; i < vertex_count; ++i) {
        if (adjacency_matrix[vertex][i] > 0) {
            next_vertices.push_back(i);
        }
    }
    return next_vertices;
}

std::vector<int> MatrixGraph::GetPrevVertices(int vertex) const {
    assert(vertex >= 0 && vertex < vertex_count);
    std::vector<int> prev_vertices;
    for (size_t i = 0; i < vertex_count; ++i) {
        if (adjacency_matrix[i][vertex] > 0) {
            prev_vertices.push_back(i);
        }
    }
    return prev_vertices;
}
