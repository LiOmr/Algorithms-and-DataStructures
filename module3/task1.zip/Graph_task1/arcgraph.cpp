#include "ArcGraph.h"

ArcGraph::ArcGraph(const IGraph &other_graph) {
    for (int i = 0; i < other_graph.VerticesCount(); ++i) {
        std::vector<int> neighbors = other_graph.GetNextVertices(i);
        for (auto &neighbor : neighbors) {
            std::pair<int, int> edge(i, neighbor);
            edges.push_back(edge);
        }
    }
}

void ArcGraph::AddEdge(int from, int to) {
    std::pair<int, int> edge(from, to);
    edges.push_back(edge);
}

int ArcGraph::VerticesCount() const {
    std::unordered_set<int> vertices;
    for (const auto &edge : edges) {
        vertices.insert(edge.first);
        vertices.insert(edge.second);
    }
    return vertices.size();
}

std::vector<int> ArcGraph::GetNextVertices(int vertex) const {
    std::vector<int> result;
    for (const auto &edge : edges) {
        if (edge.first == vertex) {
            result.push_back(edge.second);
        }
    }
    return result;
}

std::vector<int> ArcGraph::GetPrevVertices(int vertex) const {
    std::vector<int> result;
    for (const auto &edge : edges) {
        if (edge.second == vertex) {
            result.push_back(edge.first);
        }
    }
    return result;
}

ArcGraph::~ArcGraph() {}
