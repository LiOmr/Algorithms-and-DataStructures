#include "ListGraph.h"

ListGraph::ListGraph(size_t size) : graph(size) {}


ListGraph::ListGraph(const IGraph &other)
{
    for (int i = 0; i < other.VerticesCount(); ++i)
    {
        graph[i] = other.GetNextVertices(i);
    }
}

ListGraph::~ListGraph() {}

void ListGraph::AddEdge(int from, int to) {
    assert(0 <= from && from < graph.size());
    assert(0 <= to && to < graph.size());
    graph[from].push_back(to);
}

int ListGraph::VerticesCount() const { return (int)graph.size(); }

std::vector<int> ListGraph::GetNextVertices(int vertex) const {
    assert(0 <= vertex && vertex < graph.size());
    return graph[vertex];
}

std::vector<int> ListGraph::GetPrevVertices(int vertex) const
{
    assert(0 <= vertex && vertex < graph.size());
    std::vector<int> prevVertices;

    for (int from = 0; from < graph.size(); ++from)
    {
        for (int to: graph[from])
        {
            if (to == vertex)
                prevVertices.push_back(from);
        }
    }
    return prevVertices;
}
