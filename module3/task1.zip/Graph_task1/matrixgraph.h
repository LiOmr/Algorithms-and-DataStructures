#ifndef MATRIXGRAPH_H
#define MATRIXGRAPH_H

#include "IGraph.h"

class MatrixGraph : public IGraph {
public:
    explicit MatrixGraph(size_t vertex_count);
    MatrixGraph(const IGraph &other_graph);

    ~MatrixGraph();

    void AddEdge(int from, int to) override;
    int VerticesCount() const override;

    std::vector<int> GetNextVertices(int vertex) const override;
    std::vector<int> GetPrevVertices(int vertex) const override;

private:
    std::vector<std::vector<int>> adjacency_matrix;
    size_t vertex_count;
};

#endif // MATRIXGRAPH_H
